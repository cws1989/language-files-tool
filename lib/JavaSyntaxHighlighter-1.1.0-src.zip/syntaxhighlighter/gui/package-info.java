/**
 * GUI.
 */
package syntaxhighlighter.gui;