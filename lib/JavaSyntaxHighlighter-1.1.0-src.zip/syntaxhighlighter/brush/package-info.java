/**
 * All brushes that comes with release.
 */
package syntaxhighlighter.brush;