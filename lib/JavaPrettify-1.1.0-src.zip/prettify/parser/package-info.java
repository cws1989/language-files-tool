/**
 * The Prettify parser. Classes in this package are all port from JavaScript 
 * Prettify.
 */
package prettify.parser;