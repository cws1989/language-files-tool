/**
 * GUI.
 */
package prettify.gui;