package prettify.lang;

/**
 * It is included directly in the {@link prettify.Prettify}.
 */
public class LangProto {
}
